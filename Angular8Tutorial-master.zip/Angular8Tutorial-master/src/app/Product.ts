export default class Product {
  ProductName: string;
  ProductDescription: string;
  ProductPrice: number;
}
