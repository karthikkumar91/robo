export class Student {
    name: String;
}
